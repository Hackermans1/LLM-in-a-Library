"""
Sallu-Bhai: A library for converting natural language to CLI commands using Ollama's chat functionality.
"""

from .core import SalluBhai

__version__ = "0.1.0"

__all__ = ["SalluBhai"]
